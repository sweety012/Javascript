// Object literal : Object.prototype

let obj ={
    name: "harry",
    channel: "Code With Harry",
    address: "Mars"
}


function Obj(givename){
    this.name = givenName
}


obj.prototype.getName-function (){
    
    return this.name;
}


let obj2 = new Obj("Harry");
console.log(obj2);

