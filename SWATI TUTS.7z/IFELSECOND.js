
/*
If(Condition True)
    {
        Statement for True
    }
 
 else
    {
        Statement for another Condition
    }

  */


//Example 1
    var x = 15;

    if(x > 30){
        console.log("x is Greater");
    }else{
        console.log("x is smaller");
    }

//Example 2

    var name =  'Arjun';
    var gender = "male";

    if(gender == "male"){
        console.log("Hello Mr." + name);
    }else{
        console.log("Hello Mrs.");
    }

