
//For Loops:
//for(Condition; Initialization; increament/decreament)

//example 1

for (var a = 1; a<=10;a++){
    console.log("hello World");
}


//While Loops:
//var a = 1
// while(a <= 10){
//      console.log("Hello World!!!");
//      a = a + 1;
//  }

//Example for While Loops

var number = 1;

    while(number <= 25){
        console.log("Hello World");
        console.log( number + "Hello Swati");
        number = number+1;
    }


//Do While Loop
/* var a = 1;
    do{
        console.log("Hello World");
        a = a + 1;
    }while(a <= 10)
*/

var a = 1;
do{
    console.log("hello World!!!")
    a = a + 1;
} while(a <= 10)